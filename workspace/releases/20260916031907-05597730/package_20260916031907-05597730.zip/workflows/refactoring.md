# 워크플로우: 리팩토링

> 공통 사용자 개입 기준: `core/agent_rules.md`의 "사용자 부담 최소화". minor 경로는 `core/agent_rules_detail.md`의 "minor 경량 처리 절차", 독립 비평·검증의 격리·실패 처리는 `inject/_agent_execution_priority.md`를 읽고 따른다. 아래 전체 단계는 major 기준이며 minor에는 일괄 적용하지 않는다. 단계 전환만으로 사용자에게 새 작업 생성·재승인을 요구하지 않는다.

> **로드 시점:** 리팩터링 라우팅 진입 시 에이전트가 읽는다. 이 작업 유형의 특성·주의사항·세션 시퀀스를 파악한 뒤 `layer1_design.md`로 설계 세션을 시작한다.

> 기능은 유지하면서 코드 구조를 개선하는 세션 시퀀스  
> 리팩토링의 핵심 위험은 **"기능이 바뀌는 것"** — 이를 막는 게 이 워크플로우의 목적

---

## 새 기능 개발과의 차이

| 구분 | 새 기능 개발 | 리팩토링 |
|------|-------------|----------|
| 목표 | 기능 추가 | 구조 개선 |
| 성공 기준 | 새 기능 동작 | **기존 동작 100% 유지** |
| 핵심 위험 | 구현 누락 | 동작 변경 (회귀) |

---

## 사용 자원

| 구분 | 파일 |
|------|------|
| 세션 패키지 | `inject/layer0_init.md` (범위 분석) |
| 세션 패키지 | `inject/layer1_design.md` (계획) |
| 세션 패키지 | `inject/layer1_implement.md` (구현) |
| 세션 패키지 | `inject/layer1_review.md` (동작 일치 검증) |
| 페르소나 | `personas/architect.md` |
| 페르소나 | `personas/implementer.md` |
| 페르소나 | `personas/code_reviewer.md` |
| 분석 스킬 | `skills/analysis/dependency_mapping.md` |
| 분석 스킬 | `skills/analysis/path_tracing.md` |
| 분석 스킬 | `skills/analysis/counterexample_finding.md` |

---

## 전체 흐름

```
[1단계] 범위 및 의존성 분석
실행: 현재 작업에서 단계 지침을 읽고 진행
inject:  inject/layer0_init.md (또는 layer1_design.md)
         └─ 페르소나: architect
         └─ 스킬: dependency_mapping
프롬프트 추가:
  "아래 코드를 리팩토링하려고 해. 목표: [구조 개선 목표]
   1. 의존성 맵을 작성해줘
   2. 영향받는 범위를 파악해줘
   3. 기능 변경 없이 구조만 바꾸는 게 가능한지 판단해줘
   [코드 붙여넣기]"
        ↓
[2단계] 리팩토링 계획 수립
실행: 현재 작업에서 단계 지침을 읽고 진행
inject:  inject/layer1_design.md
         └─ 페르소나: plan_critic
         └─ 스킬: counterexample_finding

⚠️ 태스크 계획의 "절대 금지" 섹션 필수 포함:
- 외부 인터페이스 (public API, 함수 시그니처) 변경 금지
- 기존 동작 변경 금지
- 기존 테스트 변경 금지 (추가는 허용)
        ↓
[3단계] 구현 세션
실행: 현재 작업에서 단계 지침을 읽고 진행
inject:  inject/layer1_implement.md
         └─ 페르소나: implementer
         └─ 컨텍스트: shared/ + [2단계 태스크 계획]
핵심 지시: "기능 변경 없이 구조만 바꿔줘. 확신이 없으면 원래 코드를 유지하고 알려줘."
        ↓
[4단계] 동작 일치 검증
실행: 격리 서브에이전트 — inject/_agent_execution_priority.md 적용
inject:  inject/layer1_review.md
         └─ 페르소나: code_reviewer
         └─ 스킬: path_tracing
프롬프트 추가:
  "리팩토링 전후 코드에서 아래 경로들이 동일하게 동작하는지 확인해줘.
   정상 경로 / 실패 경로 / 엣지 케이스
   [리팩토링 전 코드] vs [리팩토링 후 코드]"
        ↓
[5단계] 회귀 테스트
기존 테스트 전체 통과 확인
        ↓
[6단계] memory 업데이트
리팩토링 과정에서 발견된 구조적 문제를 architecture.md에 추가
```

---

## 핵심 체크포인트

- [ ] 리팩토링 범위가 의존성 맵으로 명확히 정의됐는가
- [ ] 외부 인터페이스가 변경되지 않았는가
- [ ] 정상/실패/엣지 경로가 모두 동일하게 동작하는가
- [ ] 기존 테스트가 모두 통과하는가

---

## 자주 하는 실수

| 실수 | 방지 방법 |
|------|-----------|
| 추상화 중 에러 처리 누락 | 실패 경로 추적 필수 |
| 인터페이스는 같지만 동작이 달라짐 | path_tracing으로 전후 비교 |
| 테스트도 같이 "정리"해버림 | 기존 테스트 변경 금지 명시 |
| 범위가 점점 커짐 | 태스크 계획에 범위 제한 명시 |
