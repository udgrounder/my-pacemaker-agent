# 워크플로우: 버그 수정

> 공통 사용자 개입 기준: `core/agent_rules.md`의 "사용자 부담 최소화". minor 경로는 `core/agent_rules_detail.md`의 "minor 경량 처리 절차", 독립 비평·검증의 격리·실패 처리는 `inject/_agent_execution_priority.md`를 읽고 따른다. 아래 전체 단계는 major 기준이며 minor에는 일괄 적용하지 않는다. 단계 전환만으로 사용자에게 새 작업 생성·재승인을 요구하지 않는다.

> **로드 시점:** 버그 수정 라우팅 진입 시 에이전트가 읽는다. 이 작업 유형의 특성·주의사항·세션 시퀀스를 파악한 뒤 `layer1_review.md`로 검토 세션을 시작한다.

> 발견된 버그를 재현하고 최소 범위로 수정하는 세션 시퀀스  
> 새 기능 개발과 달리 **원인 파악이 먼저**, 범위 제한이 더 엄격하다

---

## 새 기능 개발과의 차이

| 구분 | 새 기능 개발 | 버그 수정 |
|------|-------------|-----------|
| 시작점 | 요구사항 | 버그 재현 |
| 핵심 작업 | 구현 | 원인 파악 |
| 범위 | 태스크 계획 기준 | **최소 변경** |
| 검증 기준 | 완료 조건 | 버그 재현 불가 + 기존 동작 유지 |

---

## 사용 자원

| 구분 | 파일 |
|------|------|
| 세션 패키지 | `inject/layer1_review.md` (원인 분석) |
| 세션 패키지 | `inject/layer1_implement.md` (수정 구현) |
| 페르소나 | `personas/code_reviewer.md` (원인 분석) |
| 페르소나 | `personas/implementer.md` (수정 구현) |
| 분석 스킬 | `skills/analysis/path_tracing.md` |
| 분석 스킬 | `skills/analysis/counterexample_finding.md` |

---

## 전체 흐름

```
[0단계] 실패 비용 추정 (에이전트가 근거를 확인)
실패비용 등급 추정 (critical / major / minor)
→ core/agent_rules_detail.md "실패비용 추정 기준" 참조 (정본)
→ 수정 전 기존 변경을 보존하고 복구 가능한 기준점 확보
        ↓
[1단계] 버그 경로 추적
실행: 격리 서브에이전트 — inject/_agent_execution_priority.md 적용
inject:  inject/layer1_review.md
         └─ 페르소나: code_reviewer
         └─ 스킬: path_tracing
프롬프트 추가:
  "아래 버그 발생 경로를 추적해줘.
   버그: [버그 설명]
   재현 조건: [재현 방법]
   예상 동작 vs 실제 동작: [비교]
   [관련 코드 붙여넣기]"
        ↓
[2단계] 수정 범위 정의 (인간이 결정)
원인 확정 후 태스크 계획 작성.

⚠️ 태스크 계획의 "절대 금지" 섹션을 엄격하게 작성:
- 수정 대상 파일만 명시 (나머지 건드리지 않음)
- 인터페이스(입출력) 변경 금지
- 기존 동작 변경 금지
        ↓
[3단계] 수정 구현 세션
실행: 현재 작업에서 단계 지침을 읽고 진행
inject:  inject/layer1_implement.md
         └─ 페르소나: implementer
         └─ 컨텍스트: shared/ + [2단계 태스크 계획]
핵심 지시: "최소 변경으로 버그만 수정해줘. 범위를 넘어서면 알려줘."
        ↓
[4단계] 검증 세션
실행: 격리 서브에이전트 — inject/_agent_execution_priority.md 적용
inject:  inject/layer1_review.md
         └─ 페르소나: code_reviewer
         └─ 스킬: counterexample_finding
프롬프트 추가:
  "이 수정이 동일한 패턴의 버그를 다른 곳에 남겨두고 있을 가능성이 있어?
   [수정된 코드 붙여넣기]"
        ↓
[5단계] memory 업데이트
유사 버그 방지를 위해 architecture.md 안티패턴 섹션 업데이트 여부 검토
```

---

## 핵심 체크포인트

- [ ] 수정 전 복구 가능한 기준점으로 롤백 지점을 확보했는가 (0단계)
- [ ] 버그 재현 경로를 명확히 파악했는가
- [ ] 수정 범위가 최소화됐는가 (인터페이스 변경 없음)
- [ ] 수정 후 버그가 재현되지 않는가
- [ ] 기존 동작이 유지되는가
- [ ] 유사 패턴의 버그가 다른 곳에 없는가
