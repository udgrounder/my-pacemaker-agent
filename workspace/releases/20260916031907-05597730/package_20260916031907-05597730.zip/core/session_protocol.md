# 세션 프로토콜

> **이 파일의 용도:**  
> `agent_rules.md`의 자동 판단 구조를 보완하는 레퍼런스.  
> 에이전트는 대부분의 경우 `agent_rules.md`의 "세션 시작 루틴"으로 자동 처리한다.  
> 이 파일은 수동 제어가 필요한 경우, 또는 전체 구조를 파악하고 싶을 때 참조한다.

---

## 수동 세션 진입 가이드

에이전트의 자동 판단을 우회하거나, 특정 세션을 명시적으로 시작하고 싶을 때:

```
새 프로젝트? 또는 기존 프로젝트에 MPA 시스템 처음 적용?
    │
    ├── Yes (새 프로젝트)           → @inject/layer0_init.md (A. 신규 흐름)
    ├── Yes (기존 프로젝트 첫 적용)  → @inject/layer0_init.md (B. 기존 흐름)
    │
    └── No (진행 중 프로젝트)
            │
            ├── 전체 워크플로우가 필요할 때 → workflows/ 참조
            │   ├── 새 기능 개발   → workflows/new_feature.md
            │   ├── 버그 수정      → workflows/bug_fix.md
            │   ├── 리팩토링       → workflows/refactoring.md
            │   ├── 코드 리뷰      → workflows/code_review.md
            │   └── 팀 협업        → workflows/team_collaboration.md
            │
            └── 단일 세션만 명시적으로 시작할 때 → inject/ 직접 사용
                ├── 기능 설계 / 계획 수립                       → @inject/layer1_design.md
                ├── 계획 독립 비평 (서브에이전트로 실행)         → @inject/layer1_critique.md
                ├── 설계 완료된 작업 항목 계획 검토·구현 승인 요청 → plan.md 검토
                ├── 에이전트 검증 (`검증 중` 단계, 서브에이전트)     → @inject/layer1_review.md
                ├── 결과물을 보고 수정·추가 사항이 생겼을 때    → @inject/layer1_discovery.md
                └── 정합성 점검                                 → @inject/layer2_checkpoint.md
```

---

## 세션별 요약

| 세션 | 페르소나 | 주입 컨텍스트 | 산출물 |
|------|---------|-------------|--------|
| layer0_init | Architect | 없음 (첫 세션) | memory 초안 전체 + tasks/INDEX.md |
| layer1_design | Task Designer | shared/ 전체 | 작업 항목 계획 (plan.md) |
| layer1_critique | Plan Critic | shared/ + plan.md만 | 비평 결과 (권장 기준 → layer1_critique.md 참조) |
| layer1_implement | Implementer | shared/ + 도메인/ + 작업 항목 계획 | 구현 코드 + 결정 목록 |
| layer1_review | Result Reviewer | shared/ + 작업 항목 계획 | 검토 리포트 |
| layer1_discovery | Task Designer | shared/ + 작업 항목 계획 | plan.md 업데이트 + INDEX.md 등록 |
| layer2_checkpoint | Integration Auditor | memory 전체 | 충돌 목록 + memory 업데이트 |

---

## 스레드 운영 원칙

inject는 단계 지침이며 새 작업 생성 명령이 아니다. 같은 작업에서도 단계가 바뀌면 해당 지침을 읽는다. 사용자 개입은 `core/agent_rules.md`의 "사용자 부담 최소화"를 따른다.

독립 비평·검증은 `inject/_agent_execution_priority.md`의 격리·산출물·실패 절차를 따른다. 설계·구현 전환이나 도메인 변경만으로 사용자가 새 작업을 열게 하지 않는다.

---

## 세션 재개 (중단된 세션 이어가기)

> 새 세션 시작 시 `agent_rules.md`의 세션 시작 루틴이 자동으로 진행 중 작업 항목을 감지하고 재개를 제안한다.
> 수동으로 이어가고 싶다면 "이어서 해줘" 또는 "[작업 항목명] 계속해줘"라고 말한다.

```
plan.md 상태 확인
    ├── "구현 중" → changelog.md 읽기 → 첫 미완료 단계부터 재개
    └── "설계 완료" → plan.md 검토 → 구현 승인 요청
```

---

## 실패비용 등급과 사용자 개입

**세션 시작 전, 먼저 실패 비용을 추정하라 (T6):**

세부 판단 기준: `core/agent_rules_detail.md` "실패비용 추정 기준" 및 "minor 경량 처리 절차" 참조 — 이것이 정본이다.

| 등급 | 조건 | 사용자 개입 (Zone) |
|------|------|-----------------|
| `critical` | 보안·외부 연동·비가역 변경 | Zone 1 — 하드 게이트, 명시적 확인 필수 |
| `major` | 그 외 기본값 | Zone 2 — 핵심 항목 확인 요청 |
| `minor` | 단일 관심사·자명한 방법·즉시 복구 가능 | Zone 3 — 완료 전 가역적 실행·기록은 자동 처리 후 간략 고지. 완료는 사용자(또는 위임 에이전트) 확인 후 처리 |

---

## 도메인 분리 원칙

**도메인별 필요한 문서를 선택해 읽는다.** 도메인 변경 자체가 새 사용자 작업이나 재승인의 근거는 아니다.

```
공통 주입:        shared/ (project_identity + architecture + contracts)
도메인별 추가:    domains/[도메인명]/rules.md + registry.md (있는 경우)
```

**도메인 걸치는 작업 (예: 로그인 end-to-end):**
```
1단계: API 계약 세션 → contracts.md 먼저 확정 (Interface-First)
2단계: [도메인 A] 세션 → 계약 구현
3단계: [도메인 B] 세션 → 계약 소비
```

API 계약 = 두 도메인 세션의 유일한 동기화 포인트  
→ 도메인 폴더 구성은 `memory/GUIDE.md` 참조
